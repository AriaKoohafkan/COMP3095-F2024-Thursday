//simulating mongo db cli
print('START');

db =db.getSiblingDB('product-service');

db.createUser(
    {
    user: "admin",
    pwd: "admin",
    roles: [{role: "readWrite", db: "product-service"}]
              }

);

db.createCollection('user');

print('END');