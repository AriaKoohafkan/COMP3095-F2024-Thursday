package ca.gbc.inventoryservice.service;

public interface InventoryService {
    boolean isInStock(String skuCode, int quantity);
}
